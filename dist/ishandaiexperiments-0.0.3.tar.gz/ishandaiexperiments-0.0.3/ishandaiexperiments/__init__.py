from .main import number_plate_detection

print(number_plate_detection())